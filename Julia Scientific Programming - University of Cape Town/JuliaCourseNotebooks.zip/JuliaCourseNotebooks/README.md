# JuliaCourseNotebooks

Jupyter notebooks for the Julia Scientific Programming course on Coursera
